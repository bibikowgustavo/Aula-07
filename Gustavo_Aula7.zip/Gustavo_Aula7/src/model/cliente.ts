export class Cliente {
    nome: string;
    fone: number;
    email: string;
}

export class ClienteList {
    key: string;
    cliente: Cliente;
}
